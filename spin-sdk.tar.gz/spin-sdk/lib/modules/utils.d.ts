import { Buffer } from "buffer";
declare const utils: {
    toBuffer(arg0: ArrayBufferView): Buffer;
};
export { utils };
